create function before_delete_question() returns trigger
    language plpgsql
as
$$
declare
    all_questions cursor is select * from question;
    question_count integer = 0;
begin
        for q in all_questions loop
        question_count := question_count + 1;
    end loop;
    if question_count <= 10 then
        raise exception 'At least 10 questions should be in table';
    end if;
    return old;
end;
$$;

alter function before_delete_question() owner to anton;

