create function before_insert_question() returns trigger
    language plpgsql
as
$$
begin
    if NEW.question_text LIKE '%?' then
        return NEW;
    end if;
    raise exception 'question text should end with `?`';
end;
$$;

alter function before_insert_question() owner to anton;

